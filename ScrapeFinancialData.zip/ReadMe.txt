Welcome to my ScrapeFinancialData project!

This project uses https://finance.yahoo.com/ to scrape financial data from companies. 
Simply enter the ticker of a desired company and hit the GetData!-button.
The financial statements are generated, among with recent stock price and company information. 
This project enables a quick way to create a comparable analysis. 

Enjoy!

Created by Arvid Landmark, May 2019.